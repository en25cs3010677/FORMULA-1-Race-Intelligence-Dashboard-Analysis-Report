# Insights (computed from race_results, 6,464 rows)

> The dataset appears simulated. Say "in this dataset" when presenting.

## Scenario 1: Team Strategist
- Points by team: Red Bull 8,006 | Mercedes 7,790 | Ferrari 5,778 | McLaren 4,270 | Alpine 1,947 | Aston Martin 1,181 | Williams 1,057 | RB 923 | Haas 591 | Kick Sauber 363
- Season-leading team (most points): Red Bull 8, Mercedes 7, McLaren 2
- Driver titles: Verstappen 7, Hamilton 7, Norris 3 (2026 is partial)
- Starting compound (avg points / podium % / DNF %):
  - Soft 5.12 / 15.4% / 7.3%
  - Hard 4.97 / 14.8% / 5.4%
  - Intermediate 4.87 / 14.3% / 5.7%
  - Medium 4.74 / 13.6% / 5.9%
- Best strategies (n>=100, avg points): Hard>Hard>Medium 6.41 | Soft>Medium>Medium 6.21 | Medium>Soft>Hard 5.88
- Pit stops: 3 stops average 5.25 pts vs 4.96 (1 stop) and 4.86 (2 stops)
- Talent pool: British drivers (Hamilton, Russell, Norris) and Dutch (Verstappen) lead on wins and points

## Scenario 2: Broadcast Analyst
- Points leaderboard: Verstappen 4,640 | Hamilton 4,491 | Perez 3,366 | Russell 3,299 | Leclerc 3,243
- Wins: Hamilton 118 | Verstappen 100 | Leclerc 44 | Norris 35
- Podiums: Verstappen 187 | Hamilton 174 | Russell 115 | Leclerc 113
- Hosts: Bahrain 115 races (data skew), then USA 20, Spain/Monaco/Hungary 17 each

## Scenario 3: Regulation Analyst
- 396 DNFs (6.1% of entries)
- Causes: Engine 73 | Hydraulics 70 | Mechanical 67 | Brake failure 64 | Gearbox 62 | Collision 60
- DNF rate by team: Haas 8.4% | RB 7.0% | Red Bull 6.9% | Aston Martin 6.9% | Ferrari 6.3% | McLaren 6.0% | Alpine 5.8% | Williams 5.8% | Kick Sauber 4.5% | Mercedes 4.3%
- Most reliable driver: Hamilton 3.6%; least: Magnussen 8.9%
- Era check: 2010-2018 5.9% vs 2019-2026 6.3%, so no improvement in this dataset
- Circuit type: Street 6.6% | Permanent 6.1% | Street/Park 5.6%
- Wet races: 5.7% DNF vs 6.2% dry
