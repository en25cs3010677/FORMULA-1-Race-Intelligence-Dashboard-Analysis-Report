# Tableau Click-by-Click

**Connect:** Connect > Text file > `data/processed/f1_clean.csv`. Set `race_date` to Date, `country` to Geographic Role > Country/Region. Use an Extract.

1. **Points Trajectory:** Columns `season`; Rows `points` (SUM); Color `team`. Right-click SUM(points) > Quick Table Calculation > Running Total (compute along `season`).
2. **Leaderboard:** Rows `driver_label`; Columns SUM(`points`); sort descending; Color `team`.
3. **Tyre Strategy:** Rows `starting_compound`; Columns AVG(`points`). Add a second sheet with `dnf` average as % (Tableau: AVG(dnf) formatted as percentage).
4. **Podiums:** Rows `driver_label`; Columns SUM(`is_podium`); filter `team`/`nationality`.
5. **Host Countries:** Create calc `Races = COUNTD([race_id])`; Rows `country`; Columns `Races`. Or double-click `country` for a map, Size = `Races`. Note Bahrain skew.
6. **Reliability / DNF:** Filter `dnf_reason` to exclude "Finished". Columns `team`; Rows COUNT(`race_id`); Color `dnf_reason` (stacked bar).
7. **DNF Rate Trend:** Columns `season`; Rows AVG(`dnf`) formatted as %.
8. **Nationality Talent Pool:** Rows `nationality`; Columns SUM(`is_win`) and SUM(`is_podium`) (dual axis or two bars).
9. **Dashboard:** KPI row (COUNTD race_id, SUM is_win, AVG dnf), then sheets 1/2 and 6/3. Add filters: `season`, `team`, `driver_label`. Dashboard > Actions > Filter (Select, all sheets).
10. **Story:** 3 points (Strategist, Broadcaster, Regulation Analyst) plus a Key Insights point.
