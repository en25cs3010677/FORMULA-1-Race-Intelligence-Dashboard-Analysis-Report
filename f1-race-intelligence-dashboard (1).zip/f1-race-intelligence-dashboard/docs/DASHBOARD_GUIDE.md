# Dashboard Build Guide (8 Phases)

## 1. Data Collection & Extraction
- [ ] Download / export dataset (CSV, Excel or SQL)
- [x] Workbook is in `data/raw/`
- [ ] Confirm ~6,464 rows across 17 seasons

## 2. Data Preparation
- [ ] Run `python scripts/prepare_data.py`
- [ ] Check nulls, duplicates, data types
- [ ] Connect Tableau to `data/processed/f1_clean.csv`

## 3. Data Visualization (worksheets)
- [ ] Championship Points Trajectory (line, by team over seasons)
- [ ] Tyre Compound vs Finishing Position (bar / box plot)
- [ ] Circuit Participation (map or bar)
- [ ] Driver Reliability & DNF (stacked bar by failure type)
- [ ] Podium Distribution (driver / team / nationality)
- [ ] Driver Performance Leaderboard
- [ ] GP Host Countries (filled map)

## 4. Dashboard
- [ ] Combine sheets on one dashboard
- [ ] Add filters: Season, Team, Driver, Circuit
- [ ] Add Filter / Highlight actions between sheets

## 5. Story
- [ ] One story point per scenario (Strategist, Broadcaster, Regulation Analyst)

## 6. Performance Testing
- [ ] Use an Extract (.hyper) instead of a live connection
- [ ] Reduce quick filters; use "Apply to context" where needed
- [ ] Run Performance Recorder (Help → Settings and Performance)

## 7. Web Integration
- [ ] Publish to Tableau Public
- [ ] Embed iframe in an HTML page / portfolio

## 8. Demonstration & Documentation
- [ ] Record demo video
- [ ] Update README with Tableau Public + demo links
- [ ] Push repo to GitHub
