# Formula 1 Race Intelligence Dashboard – Analysis Report

## Introduction
This report explores key aspects and trends in Formula 1 through visual analytics: driver performance, team championship trajectories, tyre compound strategies, circuit-level participation, driver reliability and DNF analysis, and global podium achievements. Stakeholders — team strategists, race engineers, motorsport journalists and fans — can uncover patterns, identify strengths and concerns, and make data-driven decisions. Tableau was used to produce visualizations, dashboards and a story.

## Scenario 1 – F1 Team Performance Strategist
A senior performance strategist at a mid-tier constructor benchmarks the team's championship points trajectory against Red Bull Racing and Mercedes, evaluates how tyre compound strategies (Soft, Medium, Hard, Intermediate) affect results across circuit types, and identifies which drivers and nationalities form the strongest talent pools. The dashboard (6,464 race records, 17 seasons) supports a data-driven race and recruitment strategy.

## Scenario 2 – Motorsport Broadcast Analyst
A data journalist retrieves the Driver Performance Leaderboard (cumulative points across seasons), identifies countries hosting the most Grand Prix rounds, and visualises podium distributions by driver and team for on-screen infographics, editorial pieces and fan engagement content.

## Scenario 3 – F1 Technical Regulation Analyst
An FIA compliance analyst studies DNF patterns (engine, brake, collision, mechanical) to see whether failures concentrate in particular teams or circuit types, and evaluates driver reliability across all 17 seasons to assess whether regulatory changes improved race completion rates, using the Driver Reliability stacked bar chart.

## Skills Required
Tableau (Business Intelligence Software) · Dashboard · Data Visualization (Tableau) · Data Preprocessing

## Project Stats
- Epics: 8
- Tasks: 14 · Subtasks: 0
- Complexity: Medium · Duration: 5h 0m

## Technical Architecture
Data source (Drive/DB) → Tableau → Dashboard → Tableau Public / Web → End users.
See the diagram in the main README.
