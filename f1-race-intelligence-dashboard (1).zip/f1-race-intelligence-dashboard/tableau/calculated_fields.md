# Tableau Calculated Fields (match f1_clean.csv columns)

```
// Races (distinct)
COUNTD([race_id])

// DNF Rate
AVG([dnf])

// Reliability Score (higher is better)
1 - AVG([dnf])

// Win Rate
SUM([is_win]) / COUNT([driver])

// Podium Rate
SUM([is_podium]) / COUNT([driver])

// Avg Points per Entry
SUM([points]) / COUNT([driver])

// Cumulative Points (Table Calc, along season)
RUNNING_SUM(SUM([points]))

// Season Label
STR([season])

// Era
IF [season] <= 2018 THEN "2010-2018" ELSE "2019-2026" END
```
