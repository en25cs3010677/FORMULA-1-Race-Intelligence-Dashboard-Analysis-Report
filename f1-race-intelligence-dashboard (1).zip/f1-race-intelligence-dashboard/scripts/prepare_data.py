"""Clean the Skill Wallet F1 workbook and export Tableau-ready CSVs.

Usage:
    python scripts/prepare_data.py --input data/raw/F1_Racing_Project_Dataset.xlsx
Outputs (data/processed/):
    f1_clean.csv, championship_standings.csv, lap_intelligence.csv,
    qualifying_results.csv, circuits.csv
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

# Added lookup (not in the source workbook) for the "talent pool by nationality" view.
NATIONALITY = {
    "Max Verstappen": "Dutch", "Sergio Perez": "Mexican", "Lando Norris": "British",
    "Oscar Piastri": "Australian", "Charles Leclerc": "Monegasque", "Carlos Sainz": "Spanish",
    "Alex Albon": "Thai", "Lewis Hamilton": "British", "George Russell": "British",
    "Valtteri Bottas": "Finnish", "Zhou Guanyu": "Chinese", "Esteban Ocon": "French",
    "Pierre Gasly": "French", "Fernando Alonso": "Spanish", "Lance Stroll": "Canadian",
    "Yuki Tsunoda": "Japanese", "Liam Lawson": "New Zealander",
    "Nico H\u00fclkenberg": "German", "Kevin Magnussen": "Danish",
}


def main(inp: Path, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    x = pd.ExcelFile(inp)

    r = x.parse("race_results")
    r["race_date"] = pd.to_datetime(r["race_date"])
    r["dnf_reason"] = r["dnf_reason"].fillna("Finished")
    r["is_win"] = (r["finish_position"] == 1).astype(int)
    r["is_podium"] = (r["finish_position"] <= 3).astype(int)
    r["nationality"] = r["driver"].map(NATIONALITY).fillna("Unknown")
    # Carlos Sainz appears twice per race (Ferrari AND Williams) in the source data.
    # This label keeps the two entries separate in Tableau.
    r["driver_label"] = r["driver"] + " (" + r["team"] + ")"
    r["first_compound"] = r["tyre_strategy"].str.split("\u2192").str[0]
    r["num_stints"] = r["tyre_strategy"].str.count("\u2192") + 1
    r.to_csv(outdir / "f1_clean.csv", index=False)

    x.parse("championship_standings").to_csv(outdir / "championship_standings.csv", index=False)
    x.parse("lap_intelligence").to_csv(outdir / "lap_intelligence.csv", index=False)
    x.parse("circuits").to_csv(outdir / "circuits.csv", index=False)

    q = x.parse("qualifying_results")
    # Most qualifying rows use placeholder names (Driver_N / Team_N) - flag them.
    q["is_placeholder"] = q["driver"].str.startswith("Driver_").astype(int)
    q.to_csv(outdir / "qualifying_results.csv", index=False)

    print(f"race_results: {len(r)} rows | seasons {r.season.nunique()} | races {r.race_id.nunique()}")
    print(f"placeholder qualifying rows: {int(q.is_placeholder.sum())} of {len(q)}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="data/raw/F1_Racing_Project_Dataset.xlsx", type=Path)
    p.add_argument("--output", default="data/processed", type=Path)
    a = p.parse_args()
    main(a.input, a.output)
