# 🏎️ Formula 1 Race Intelligence Dashboard (Tableau)

An interactive **Tableau** analytics project exploring 17 seasons of Formula 1 racing (**6,464 race records**): driver performance, team championship trajectories, tyre compound strategy, circuit participation, reliability / DNF analysis and global podium achievements.

> Built as part of the **Skill Wallet (SmartBridge)** project programme. Skills: Tableau · Dashboard Design · Data Visualization · Data Preprocessing.

---

## 📌 Table of Contents
- [Project Overview](#-project-overview)
- [Scenarios](#-scenarios)
- [Technical Architecture](#-technical-architecture)
- [Repository Structure](#-repository-structure)
- [Getting Started](#-getting-started)
- [Data Schema](#-data-schema)
- [Project Phases](#-project-phases)
- [System Requirements](#-system-requirements)
- [Screenshots](#-screenshots)
- [Author](#-author)

## 📖 Project Overview
This project turns raw F1 race results into a visual decision-support tool for team strategists, race engineers, motorsport journalists and fans. Tableau was used to build worksheets, a dashboard and a story that let stakeholders:
- Track **championship points trajectories** across seasons
- Compare **tyre compound strategies** (Soft, Medium, Hard, Intermediate) and their effect on race outcomes
- Analyse **circuit-level** participation and **countries hosting** the most Grand Prix rounds
- Evaluate **driver reliability** and **DNF causes** (engine, brakes, collisions, mechanical)
- Visualise **podium distributions** by driver, team and nationality

## 🎭 Scenarios
| # | Persona | Goal |
|---|---------|------|
| 1 | **F1 Team Performance Strategist** | Benchmark points trajectory vs. top teams, evaluate tyre strategies, find strong talent pools by nationality |
| 2 | **Motorsport Broadcast Analyst** | Pull leaderboards, top Grand Prix host countries and podium infographics for broadcast/editorial content |
| 3 | **F1 Technical Regulation Analyst** | Study DNF patterns and reliability scores across 17 seasons to assess regulatory impact |

## 🏗️ Technical Architecture
```mermaid
flowchart LR
    A[(Data Source<br/>Excel / CSV / SQL)] --> B[Tableau<br/>Data Connection]
    B --> C[Data Preparation<br/>Cleaning & Calculated Fields]
    C --> D[Worksheets<br/>Visualizations]
    D --> E[Dashboard & Story]
    E --> F[Tableau Public / Web Integration]
    F --> G((End Users))
```

## 📁 Repository Structure
```
f1-race-intelligence-dashboard/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
├── data/
│   ├── raw/                  # original Skill Wallet workbook (.xlsx)
│   └── processed/            # Tableau-ready CSVs
├── scripts/
│   └── prepare_data.py       # cleaning + derived columns
├── tableau/
│   ├── README.md             # where to place .twbx / .twb
│   └── calculated_fields.md  # all Tableau calculations
└── docs/
    ├── PROJECT_REPORT.md
    ├── INSIGHTS.md           # findings computed from the dataset
    ├── TABLEAU_STEPS.md      # click-by-click sheet instructions
    ├── DASHBOARD_GUIDE.md
    └── screenshots/
```

## 🚀 Getting Started
```bash
git clone https://github.com/<your-username>/f1-race-intelligence-dashboard.git
cd f1-race-intelligence-dashboard
pip install -r requirements.txt openpyxl

# Regenerate the Tableau-ready CSVs from the workbook
python scripts/prepare_data.py

# Then in Tableau: Connect -> Text file -> data/processed/f1_clean.csv
```

## 🗂️ Data Schema
Source workbook `data/raw/F1_Racing_Project_Dataset.xlsx` has 5 sheets:

| Sheet | Rows | Use |
|-------|------|-----|
| `race_results` | 6,464 | Main fact table: 334 races, 2010-2026, 19 drivers, 10 teams |
| `championship_standings` | 311 | Season standings, wins, podiums, champion flag |
| `lap_intelligence` | 3,814 | Lap/sector times, tyre age, DRS, speed trap |
| `qualifying_results` | 3,130 | Qualifying times (mostly placeholder names, see notes) |
| `circuits` | 29 | Circuit type, altitude, direction |

Key `race_results` columns: `season, round, circuit_name, country, weather, is_wet_race, finish_position, grid_position, positions_gained, driver, team, points, dnf, dnf_reason, pit_stops, avg_pit_stop_time_s, tyre_strategy, starting_compound, laps_led`.

Derived by the script: `is_win, is_podium, nationality, driver_label, first_compound, num_stints`.

### Data notes
- The dataset looks **simulated** (e.g. current-era drivers appear in all 17 seasons). Treat findings as "in this dataset", not real F1 history.
- **Carlos Sainz appears twice in every race** (Ferrari and Williams). Use `driver_label` to keep them separate.
- `qualifying_results`: 2,817 of 3,130 rows have placeholder names (`Driver_N`, `Team_N`); flagged with `is_placeholder`.
- **Bahrain hosts 115 of 334 races**; this skews host-country charts.
- **2026 is a partial season** (12 races, last on 2026-08-02).
- `nationality` is an added lookup, not in the source.

## 🧭 Project Phases
1. Data Collection & Extraction from Database
2. Data Preparation
3. Data Visualization
4. Dashboard
5. Story
6. Performance Testing
7. Web Integration
8. Project Demonstration & Documentation

Details: [`docs/DASHBOARD_GUIDE.md`](docs/DASHBOARD_GUIDE.md)

## 💻 System Requirements
- **CPU:** Dual-core (i3 or equivalent) — recommended i5 / Ryzen 5+
- **RAM:** min 8 GB — recommended 16 GB
- **Storage:** min 2–3 GB free — recommended SSD with 10+ GB
- **OS:** Windows 10/11 (64-bit) or macOS (latest)
- **Software:** Tableau Desktop or Tableau Public
- **Browser:** latest Chrome, Edge or Safari
- **Data sources:** Excel, CSV or SQL databases

## 🔍 Key Insights (from this dataset)
- **Top team by points:** Red Bull Racing (8,006), then Mercedes (7,790) and Ferrari (5,778)
- **Season-leading team:** Red Bull 8 seasons, Mercedes 7, McLaren 2
- **Most wins:** Lewis Hamilton 118, Max Verstappen 100, Charles Leclerc 44
- **Tyres:** Soft starts score the most points (5.12 avg) but have the highest DNF rate (7.3%)
- **Most reliable team:** Mercedes (4.3% DNF); least reliable: Haas (8.4%)
- **Most common DNF cause:** Engine (73 of 396), but all six causes are close
- Full details: [`docs/INSIGHTS.md`](docs/INSIGHTS.md)

## 🖼️ Screenshots
| Overview | Scenarios & Skills | Architecture |
|---|---|---|
| ![overview](docs/screenshots/01-overview.png) | ![scenarios](docs/screenshots/02-scenarios-skills.png) | ![arch](docs/screenshots/03-architecture-requirements.png) |

## 👤 Author
**Ali** — CSE student, aspiring AI/ML Engineer.
- GitHub: `https://github.com/<your-username>`
- Tableau Public: `<add your link here>`

## 📄 License
MIT — see [LICENSE](LICENSE).
